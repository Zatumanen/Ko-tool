
function powerOn() {
  const btn = document.querySelector('.power-button');
  const screen = document.getElementById('screen');
  btn.classList.toggle('on');
  screen.innerHTML = '<p>Sampler готов</p>';
}

function openSampler() {
  if (document.querySelector('.power-button').classList.contains('on')) {
    document.getElementById('controls').style.display = 'block';
    document.getElementById('screen').innerHTML = '<p>Загрузи файл</p>';
  }
}

const dropZone = document.getElementById('drop-zone');
dropZone.addEventListener('dragover', (e) => {
  e.preventDefault();
  dropZone.style.borderColor = '#0f0';
});
dropZone.addEventListener('dragleave', () => {
  dropZone.style.borderColor = '#666';
});
dropZone.addEventListener('drop', (e) => {
  e.preventDefault();
  const file = e.dataTransfer.files[0];
  if (file) {
    alert('Загружен: ' + file.name);
  }
});
